from turtle import clear
from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask import session
from datetime import datetime
from flask import jsonify

import hashlib 
import logging
current_utc_time = datetime.utcnow()

app = Flask(__name__, template_folder="Login_page_for_sttudent")
app.config['TEMPLATES_AUTO_RELOAD'] = True
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://sql5666942:1PhyAVK6Dy@sql5.freesqldatabase.com/sql5666942'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'ABCabcDEFdef123'

db = SQLAlchemy(app)

# Define the User_Credentials model without an id column
class User_Registration(db.Model):
    __tablename__ = 'User_Registration'  # Specify the exact table name
    First_name= db.Column(db.String(255), nullable=False)
    Last_name= db.Column(db.String(255), nullable=False)
    Email = db.Column(db.String(255), primary_key=True) 
    Clark_ID = db.Column(db.String(9), nullable=False)
    Student_Type = db.Column(db.String(255), nullable=False) 
    Password = db.Column(db.String(255), nullable=False)
    Account_Status = db.Column(db.String(255), nullable=False)

class Course_Details(db.Model):
     __tablename__ = 'Course_Details'
     id = db.Column(db.Integer, primary_key=True, autoincrement=True)
     Email=db.Column(db.String(255), nullable=False)
     Course_Name= db.Column(db.String(255), nullable=False)
     Course_Code= db.Column(db.String(255), nullable=False)
     Faculty_Email = db.Column(db.String(255), nullable=False) 
     Enrollment_Year = db.Column(db.Integer, nullable=False)
     Enrollment_Term = db.Column(db.String(6), nullable=False)
     Grade=db.Column(db.String(2), nullable=False)

class TA_Applications(db.Model):
    __tablename__ = 'TA_Applications'
    A_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    A_Email = db.Column(db.String(255), nullable=False)
    A_Course_name = db.Column(db.String(255), nullable=False)
    A_Course_code = db.Column(db.String(255), nullable=False)
    A_Prev_taken = db.Column(db.String(255), nullable=False)
    A_Grade = db.Column(db.String(255), nullable=False)
    A_Cover_letter = db.Column(db.String(255), nullable=False)
    A_Resume = db.Column(db.String(255), nullable=False)
    A_Status = db.Column(db.String(255), nullable=False)
    A_Validated = db.Column(db.String(3), nullable=False)
    A_Submission_date = db.Column(db.DateTime, default=datetime.utcnow)

class TA_Applications_Decisions(db.Model):
    __tablename__ = 'TA_Applications_Decisions'
    D_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    D_Student_Email = db.Column(db.String(255), nullable=False)
    D_Prof_Email = db.Column(db.String(255), nullable=False)
    D_Course_Name = db.Column(db.String(255), nullable=False)
    D_Course_Code = db.Column(db.String(255), nullable=False)
    D_Course_Grade = db.Column(db.String(2), nullable=False)
    D_Decision = db.Column(db.String(255), nullable=False)
    D_Decision_Date = db.Column(db.DateTime, default=datetime.utcnow)

class Faculty_login_details(db.Model):
    __tablename__ = 'Faculty_login_details'
    Faculty_email = db.Column(db.String(255), primary_key=True) 
    Faculty_password = db.Column(db.String(255), nullable=False)

class Admin_login_details(db.Model):
     __tablename__ ='Admin_login_details'
     Admin_email = db.Column(db.String(255), primary_key=True) 
     Admin_password = db.Column(db.String(255), nullable=False)

class Faculty_Courses(db.Model):
    __tablename__ = 'Faculty_Courses'
    F_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    F_Email = db.Column(db.String(255), nullable=False) 
    F_Year = db.Column(db.Integer, nullable=False)
    F_Term = db.Column(db.String(255), nullable=False) 
    F_Course_Name = db.Column(db.String(255), nullable=False) 
    F_Course_Code = db.Column(db.String(255), nullable=False) 



def hash_password(password):
    salt = "SEPROJECT2023"  # Replace with a secure random salt
    password = password + salt
    return hashlib.sha256(password.encode()).hexdigest()


@app.route('/')
def index():
    return render_template('land.html')
    #return render_template('Student_login.html')

@app.route('/Student_login.html')
def sl():
    return render_template('Student_login.html')

@app.route('/Faculty_login.html')
def fac_login():
    return render_template('Faculty_login.html')

@app.route('/Admin_login.html')
def adm_login():
    return render_template('Admin_login.html')

@app.route('/Registration_page.html')
def registration_page1():
    return render_template('Registration_page.html')

@app.route('/Next_page.html')
def registration_page2():
    return render_template('Next_page.html')

@app.route('/Student_login.html')
def login_page():
    return render_template('Student_login.html')

@app.route('/ta.html')
def student_home():
    username = session.get('username')
    return render_template('ta.html', username=username)

@app.route('/Faculty_Home_Page.html')
def faculty_home():
    username = session.get('username')
    return render_template('Faculty_Home_Page.html', username=username)

@app.route('/Admin_Home_Page.html')
def admin_home():
    username = session.get('username')
    return render_template('Admin_Home_Page.html', username=username)

@app.route('/TA_Apply.html')
def apply_TA():
    username = session.get('username')
    return render_template('TA_Apply.html', username=username)

@app.route('/F_Filter.html')
def search_apps():
    username = session.get('username')
    
    try:
        # Query all courses from the Course table
        courses = Faculty_Courses.query.filter_by(F_Email=username)

        # Convert the query result to a list of dictionaries
        course_list = [{'courseCode': course.F_Course_Code , 'courseName': course.F_Course_Name} for course in courses]
        return render_template('F_Filter.html', username=username, course_list=course_list)
        #return jsonify(course_list)

    except Exception as e:
        return jsonify({'error': str(e)})
    

@app.route('/Add_Courses.html')
def add_courses_page():
    username = session.get('username')
    return render_template('Add_Courses.html', username=username)

@app.route('/Faculty_set_courses.html')
def setcourses():
    username=session.get('username')
    return render_template('Faculty_set_courses.html', username=username)

@app.route('/Filter_Applications.html')
def makedecision():
    username = session.get('username')
    return render_template('Filter_Applications.html', username=username)

@app.route('/Past_Activities.html')
def pastactivities():
    username = session.get('username')
    return render_template('Past_Activities.html', username = username)

@app.route('/Recent_Activities.html')
def recentactivities():
    username = session.get('username')
    return render_template('Recent_Activities.html', username = username)

@app.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        email = request.form['Username']
        pwd = request.form['Password']
        hash_pwd = hash_password(pwd)

        user = User_Registration.query.filter_by(Email=email).first()

        if user:
            if hash_pwd == user.Password:
                flash("User validated, Login Successful")
                session['username'] = user.Email
                return redirect(url_for('student_home'))
            else:
                flash("User validated, Login Failed - Invalid Password")

        else:
            flash("User not found")

        return redirect(url_for('sl'))
    
@app.route('/faculty_login', methods=['POST'])
def faculty_login():
    if request.method == 'POST':
        email = request.form['F_Username']
        pwd = request.form['F_Password']
        #hash_pwd = hash_password(pwd)

        user = Faculty_login_details.query.filter_by(Faculty_email=email).first()

        if user:
            if pwd == user.Faculty_password:
                flash("User validated, Login Successful")
                session['username'] = user.Faculty_email
                return redirect(url_for('faculty_home'))
            else:
                flash("User validated, Login Failed - Invalid Password")

        else:
            flash("User not found")

        return redirect(url_for('fac_login'))
    
@app.route('/admin_login', methods=['POST'])
def admin_login():
    if request.method == 'POST':
        email = request.form['A_Username']
        pwd = request.form['A_Password']
        #hash_pwd = hash_password(pwd)

        user = Admin_login_details.query.filter_by(Admin_email=email).first()

        if user:
            if pwd == user.Admin_password:
                flash("User validated, Login Successful")
                session['username'] = user.Admin_email
                return redirect(url_for('admin_home'))
            else:
                flash("User validated, Login Failed - Invalid Password")

        else:
            flash("User not found")

        return redirect(url_for('adm_login'))

@app.route('/s_logout')
def s_logout():
    # Clear the user session
    session.pop('username', None)
    flash("Logged out successfully", "success")
    return redirect(url_for('sl'))

@app.route('/f_logout')
def f_logout():
    # Clear the user session
    session.pop('username', None)
    flash("Logged out successfully", "success")
    return redirect(url_for('fac_login'))

@app.route('/a_logout')
def a_logout():
    # Clear the user session
    session.pop('username', None)
    flash("Logged out successfully", "success")
    return redirect(url_for('adm_login'))


@app.route('/register1', methods=['GET', 'POST'])
def register1():

    First_name = None
    Last_name = None
    Email = None
    Clark_ID = None
    Student_Type = None
    Password = None

    if request.method == 'POST':
        First_name = request.form.get('First_name')
        Last_name = request.form.get('Last_name')
        Email = request.form.get('Email')
        Clark_ID = request.form.get('Clark_ID')
        Student_Type = request.form.get('Student_Type')
        Pwd = request.form.get('Password')
        Password = hash_password(Pwd)
        print(Student_Type)
        return redirect(url_for('register2', First_name=First_name, Last_name=Last_name, Email=Email, Clark_ID=Clark_ID, Student_Type=Student_Type, Password=Password))
        

@app.route('/register2', methods=['GET', 'POST'])
def register2():
    #if request.method == 'POST':
    First_name = request.args.get('First_name')
    Last_name = request.args.get('Last_name')
    Email = request.args.get('Email')
    Clark_ID = request.args.get('Clark_ID')
    Student_Type = request.args.get('Student_Type')
    Password= request.args.get('Password')
    return render_template('Next_page.html', First_name=First_name, Last_name=Last_name, Email=Email, Clark_ID=Clark_ID, Student_Type=Student_Type, Password=Password)

@app.route('/final', methods=['GET', 'POST'])
def final():
    
    First_name = request.form.get('First_name')
    Last_name = request.form.get('Last_name')
    Email = request.form.get('Email')
    Clark_ID = request.form.get('Clark_ID')
    Student_Type = request.form.get('Student_Type')
    Password= request.form.get('Password')

    user=User_Registration(First_name=First_name, Last_name=Last_name, Email=Email, Clark_ID=Clark_ID, Student_Type=Student_Type, Account_Status='Pending', Password=Password)
    print(Student_Type)
    print(Email)
    try:
        db.session.add(user)
        db.session.commit()
        flash('User registered successfully', 'success')
    except Exception as e:
        flash(f'Error: {str(e)}', 'error')
        db.session.rollback()
    
    if request.method == 'POST':
        course_names = request.form.getlist('A[]')
        course_codes = request.form.getlist('B[]')
        faculty_emails = request.form.getlist('C[]')
        enroll_years = request.form.getlist('D[]')
        terms = request.form.getlist('E[]')
        grades = request.form.getlist('F[]')

    for i in range(len(course_names)):
            Email = request.form.get('Email')
            add=Course_Details(Email=Email, Course_Name=course_names[i], Course_Code=course_codes[i], Faculty_Email=faculty_emails[i], Enrollment_Year=enroll_years[i], Enrollment_Term=terms[i], Grade=grades[i])
            db.session.add(add)
            db.session.commit()

    return redirect(url_for('index'))

@app.route('/view_Courses', methods=['GET','POST'])
def view_Courses():
    mail = session.get('username')
    view = Course_Details.query.filter_by(Email=mail).all()
    return render_template('Add_Courses.html', view=view)
        

@app.route('/add_Courses', methods=['GET', 'POST'])
def add_Courses():
    if request.method == 'POST':
        uname = session.get('username')
        course_names = request.form.getlist('A[]')
        course_codes = request.form.getlist('B[]')
        faculty_emails = request.form.getlist('C[]')
        enroll_years = request.form.getlist('D[]')
        terms = request.form.getlist('E[]')
        grades = request.form.getlist('F[]')

        for i in range(len(course_names)):
                ac=Course_Details(Email=uname, Course_Name=course_names[i], Course_Code=course_codes[i], Faculty_Email=faculty_emails[i], Enrollment_Year=enroll_years[i], Enrollment_Term=terms[i], Grade=grades[i])
                db.session.add(ac)
                db.session.commit()
        return render_template('Add_Courses.html')

@app.route('/edit_profile', methods=['GET', 'POST'])
def edit_profile():
    username = session.get('username')
    user = User_Registration.query.filter_by(Email=username).first()
    
    if request.method == 'POST':
        user.First_name = request.form['First_name']
        user.Last_name = request.form['Last_name']
        user.Email = request.form['Email']
        user.Clark_ID = request.form['Clark_ID']
        user.Intake_year = request.form['Intake_year']
        user.Intake_term = request.form['Intake_term']
        user.Pronouns = request.form['Pronouns']
        user.Phone = request.form['Phone']
        db.session.commit()
        #return redirect(url_for('profile'))
    return render_template('edit_profile.html', user=user)

@app.route('/applyTA', methods=['GET', 'POST'])
def applyTA():
    A_Email = session.get('username')
    if request.method == 'POST':
       
        A_Course_name = request.form.get('A_Course_name')
        A_Course_code = request.form.get('A_Course_code')
        A_Prev_taken = request.form.get('A_Prev_taken')
        A_Grade = request.form.get('A_Grade')
        A_Resume = request.form.get('A_Resume')
        A_Cover_letter = request.form.get('A_Cover_letter')
        TA=TA_Applications(A_Email=A_Email, A_Course_name = A_Course_name, A_Prev_taken = A_Prev_taken, A_Course_code = A_Course_code, A_Cover_letter = A_Cover_letter, A_Resume = A_Resume, A_Grade = A_Grade, A_Status="Submitted", A_Validated="No")
        db.session.add(TA)
        db.session.commit()
    #return redirect(url_for('student_home'))
    return render_template('TA_Apply.html', TA=TA)

@app.route('/display_data')
def display_data():
    email = session.get('username')
    # Fetch data from the database table based on the user's email
    data = TA_Applications.query.filter_by(A_Email=email).all()
    return render_template('Application_status.html', data=data)

@app.route('/past_activities')
def past_activities():
    prof_email = session.get('username')
    # Fetch data from the database table based on the user's email
    data = TA_Applications_Decisions.query.filter_by(D_Prof_Email=prof_email).all()
    print(data)
    return render_template('Past_Activities.html', data=data)

@app.route('/recent_activities')
def recent_activities():
    # Fetch data from the database table based on the user's email
    data = TA_Applications_Decisions.query.all()
    return render_template('Recent_Activities.html', data=data)

@app.route('/search', methods=['GET', 'POST'])
def search():
    if request.method == 'GET':
        course_code = request.args.get('courseCode')

        # Query the database for records with the specified course code
        results = TA_Applications.query.filter_by(A_Course_code=course_code, A_Status = 'Submitted', A_Validated = 'Yes').all()

        return render_template('Filter_Applications.html', results=results)
    
@app.route('/make_decision', methods=['POST'])
def make_decision():
    prof_email = session.get('username')
    decision = request.form['decision']
    application_id = request.form['id']
    coursecode = request.form['course_code']
    coursename = request.form['course_name']
    coursegrade = request.form['course_grade']
    print(f'Decision: {decision}, Application ID: {application_id}')

    # Get the TA application from the database
    ta_application = TA_Applications.query.filter_by(A_Email = application_id, A_Course_code = coursecode ).first()

    if ta_application:
        # Update the 'A_Status' column based on the decision (if needed)
        if decision == 'approved':
            ta_application.A_Status = 'Approved'
        elif decision == 'rejected':
            ta_application.A_Status = 'Rejected'
        
        db.session.commit()
        print(f'Decision: {ta_application.A_Status}, Application ID: {application_id}')
        flash(f'Decision: {decision} for TA Application ID: {application_id} was successful', 'success')
    else:
        flash(f'Error: TA Application not found', 'error')

    ta_decision = TA_Applications_Decisions(D_Student_Email = application_id , D_Prof_Email = prof_email , D_Course_Name = coursename, D_Course_Code = coursecode, D_Decision = ta_application.A_Status, D_Course_Grade = coursegrade) 
    db.session.add(ta_decision)
    db.session.commit()
    return render_template('Filter_Applications.html')

#********************************************************************************************************************************************************************************************************************************************************
#********************************************************************************************************************************************************************************************************************************************************
@app.route('/admin_search', methods=['GET', 'POST'])
def admin_search():
    if request.method == 'GET':

        # Query the database for records with the specified course code
        results = TA_Applications.query.filter_by(A_Status = 'Submitted', A_Validated = 'No').all()

        return render_template('Admin_Approval.html', results=results)
    
@app.route('/admin_make_decision', methods=['POST'])
def admin_make_decision():
    prof_email = session.get('username')
    decision = request.form['decision']
    application_id = request.form['id']
    coursecode = request.form['course_code']
    coursename = request.form['course_name']
    coursegrade = request.form['course_grade']
    print(f'Decision: {decision}, Application ID: {application_id}')

    # Get the TA application from the database
    ta_application = TA_Applications.query.filter_by(A_Email = application_id, A_Course_code = coursecode ).first()

    if ta_application:
        # Update the 'A_Status' column based on the decision (if needed)
        if decision == 'yes':
            ta_application.A_Validated = 'Yes'
        elif decision == 'no':
            ta_application.A_Validated = 'No'
        
        db.session.commit()
        print(f'Decision: {ta_application.A_Validated}, Application ID: {application_id}')
        flash(f'Decision: {decision} for TA Application ID: {application_id} was successful', 'success')
    else:
        flash(f'Error: TA Application not found', 'error')
    return render_template('Admin_Approval.html', prof_email=prof_email)
    
@app.route('/withdraw_application', methods=['POST'])
def withdraw_application():
    email = request.form.get('email')

    TA_Applications.query.filter_by(A_Email=email, A_Status='Submitted').delete()
    db.session.commit()
    return render_template('Application_Status.html')

@app.route('/set_courses', methods=['POST'])
def set_courses():
    F_Email= session.get('username')
    if request.method == 'POST':
        cnames = request.form.getlist('C1[]')
        ccodes = request.form.getlist('C2[]')
        y = request.form.getlist('y[]')
        t = request.form.getlist('t[]')

    for i in range(len(cnames)):
            add=Faculty_Courses(F_Email=F_Email, F_Course_Name=cnames[i], F_Course_Code=ccodes[i], F_Year=y[i], F_Term=t[i])
            db.session.add(add)
            db.session.commit()

    return render_template('Faculty_set_courses.html', add=add)


if __name__ == '__main__':
    app.run(debug=True)